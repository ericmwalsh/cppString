README

STUDENT NAME :: ERIC M WALSH
STUDENT ID # :: 861-041-273

CS014 KLEFSTAD WINTER 2014 - HOMEWORK ASSIGNMENT #2

NOTES:  I did not include a makefile because I did not have time.

I have three files:
- MyString.h (Header file) - I added two new methods for testing purposes.
- MyString.cpp (Source file)
- testMyString.cpp (this file is used to test MyString - I have written multiple methods with console input detailing testing)


I did not run into any problems except operator+= took quite a while but everything is 100% fully functioning.




AS FAR AS THE MAKEFILE - you can compile testMyString.cpp with MyString.h and MyString.cpp in the folder and it should compile correctly.  Currently the main() method in testMyString.cpp is blank - however there are 6 tester methods meant to showcase MyString's functionality.